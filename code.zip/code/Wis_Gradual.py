import numpy as np
import geopandas as gpd
from shapely.geometry import Point
import os

# Exact bounds from your polygon
X_MIN = 0.0511
X_MAX = 10.0438
Y_MIN = 0.0417
Y_MAX = 9.8090

N_POINTS = 1_000_000
CRS = "EPSG:5070"

OUTPUT_PATH = r"C:\Users\Olatu\Desktop\Thesis_Data\LowHighLowHigh_MiddleBoost.shp"

np.random.seed(42)

print("Generating low-high-low-high with middle boost...")

# Uniform candidates
x = np.random.uniform(X_MIN, X_MAX, N_POINTS)
y = np.random.uniform(Y_MIN, Y_MAX, N_POINTS)

# Normalized versions (required for wave functions)
xn = (x - X_MIN) / (X_MAX - X_MIN)
yn = (y - Y_MIN) / (Y_MAX - Y_MIN)

# Center peak (highest density around middle x ≈ 5 m)
center_boost = 6.0 * np.exp(-((x - 5.05)**2) / (2 * 2.5**2))

# Low-high-low-high wave pattern
wave = (
    5.5 * np.sin(3.0 * np.pi * xn) +
    3.2 * np.sin(4.2 * np.pi * xn + 1.0) +
    1.8 * np.cos(2.8 * np.pi * yn)
)

# Combine
density = 1.0 + center_boost + wave + np.random.normal(0, 0.10, N_POINTS)

# Ensure positive + minimum density floor
density = np.maximum(density, 0.7)

# Contrast boost
density = density ** 1.65

# Normalize
density /= density.sum()

# Sample + small jitter
indices = np.random.choice(N_POINTS, N_POINTS, p=density, replace=True)
x_final = x[indices] + np.random.normal(0, 0.03, N_POINTS)
y_final = y[indices] + np.random.normal(0, 0.03, N_POINTS)

x_final = np.clip(x_final, X_MIN, X_MAX)
y_final = np.clip(y_final, Y_MIN, Y_MAX)

# Create GeoDataFrame
gdf = gpd.GeoDataFrame(
    {'x': x_final, 'y': y_final},
    geometry=[Point(xy) for xy in zip(x_final, y_final)],
    crs=CRS
)

os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
gdf.to_file(OUTPUT_PATH, driver='ESRI Shapefile', encoding='utf-8')

print(f"\nDone! Saved to: {OUTPUT_PATH}")
print("→ Should now show low-high-low-high bands + highest density in the middle")