import numpy as np
import geopandas as gpd
from shapely.geometry import Point
import os

# ================================================
#   6 STRONG HOTSPOTS in NON-ORDERLY MANNER + PLENTY OF NOISE (tricky pattern)
#   - 6 clear hotspots with roughly equal population (~16.7% each)
#   - Placed randomly (non-orderly)
#   - Heavy noise everywhere: lots of random scatter + misleading small clusters
#   - Overall very tricky to discern the 6 main hotspots from noise
#   - CRS: EPSG:5070
#   - Matches your ~10 m × 10 m extent
# ================================================

# Your polygon's exact extent
X_MIN = 0.0511
X_MAX = 10.0438
Y_MIN = 0.0417
Y_MAX = 9.8090

N_POINTS = 1_000_000
CRS = "EPSG:5070"

OUTPUT_PATH = r"C:\Users\Olatu\Desktop\Thesis_Data\6_NonOrderly_Hotspots_Tricky_Noise.shp"

np.random.seed(42)

print("Generating 6 non-orderly hotspots with plenty of noise...")

# Uniform candidates
x = np.random.uniform(X_MIN, X_MAX, N_POINTS)
y = np.random.uniform(Y_MIN, Y_MAX, N_POINTS)

# 6 hotspot definitions: (cx, cy, sigma=spread, amp=peak)
# Positions randomized (non-orderly), amp/sigma tuned for equal pop
hotspots = [
    (3.7, 1.9, 0.65, 15.0),   # bottom-ish
    (1.4, 5.8, 0.65, 15.0),   # left-middle
    (6.1, 8.2, 0.65, 15.0),   # upper-center
    (8.9, 4.1, 0.65, 15.0),   # right-middle
    (4.8, 6.7, 0.65, 15.0),   # center-upper
    (7.2, 2.6, 0.65, 15.0)    # bottom-right-ish
]

# Build hotspot density
density = np.zeros(N_POINTS)

for cx, cy, sigma, amp in hotspots:
    dist_sq = (x - cx)**2 + (y - cy)**2
    gaussian = amp * np.exp(-dist_sq / (2 * sigma**2))
    density += gaussian

# Low base background
density += 0.06

# === PLENTY OF NOISE – makes it very tricky ===
# Layer 1: medium random clusters (many fake small hotspots)
noise_medium = 2.0 * np.random.normal(0, 1.5, N_POINTS)
# Layer 2: fine dense scatter (heavy background points)
noise_fine   = 2.5 * np.random.normal(0, 1.2, N_POINTS)
# Layer 3: very fine chaotic grain
noise_grain  = 1.8 * np.random.normal(0, 0.9, N_POINTS)
# Layer 4: extra spikes (misleading mini-clusters)
noise_spikes = 1.5 * np.abs(np.random.normal(0, 1.0, N_POINTS))

density += noise_medium + noise_fine + noise_grain + noise_spikes

# Non-negative
density = np.maximum(density, 0)

# Moderate-strong contrast → hotspots visible but buried in noise
density = density ** 2.6

# Normalize
density /= density.sum()

# Sample points
indices = np.random.choice(N_POINTS, N_POINTS, p=density, replace=True)

# Small jitter (~3 cm)
x_final = x[indices] + np.random.normal(0, 0.03, N_POINTS)
y_final = y[indices] + np.random.normal(0, 0.03, N_POINTS)

x_final = np.clip(x_final, X_MIN, X_MAX)
y_final = np.clip(y_final, Y_MIN, Y_MAX)

# Create GeoDataFrame
gdf = gpd.GeoDataFrame(
    {'x': x_final, 'y': y_final},
    geometry=[Point(xy) for xy in zip(x_final, y_final)],
    crs=CRS
)

# Save
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
gdf.to_file(OUTPUT_PATH, driver='ESRI Shapefile', encoding='utf-8')

print(f"\nDone! File saved to:")
print(OUTPUT_PATH)
print(f"→ {len(gdf):,} points")
print("\nExpected appearance:")
print("- 6 strong hotspots in non-orderly positions")
print("- Roughly equal population in each hotspot")
print("- Plenty of noise: random scatter + many small misleading clusters everywhere")
print("- Very tricky: noise makes hotspots hard to spot at first glance")
print("Style in ArcGIS Pro: small point size (1–1.3 pt), bright color, no fill")
print("Zoom in/out → pattern is ambiguous and requires close study")