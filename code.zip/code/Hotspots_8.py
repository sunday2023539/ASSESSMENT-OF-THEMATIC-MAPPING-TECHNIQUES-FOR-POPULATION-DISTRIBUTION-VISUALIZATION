import numpy as np
import geopandas as gpd
from shapely.geometry import Point
import os

# ================================================
#   8 STRONG HOTSPOTS in NON-ORDERLY MANNER + PLENTY OF NOISE (tricky pattern)
#   - 8 clear but irregular hotspots with roughly equal population (~12.5% each)
#   - Non-orderly / scattered placement (no symmetry)
#   - Heavy noise everywhere: random scatter + many misleading small clusters
#   - Very tricky to identify the 8 main hotspots
#   - CRS: EPSG:5070
#   - Matches your ~10 m × 10 m extent
# ================================================

# Your polygon's exact extent
X_MIN = 0.0511
X_MAX = 10.0438
Y_MIN = 0.0417
Y_MAX = 9.8090

N_POINTS = 1_000_000
CRS = "EPSG:5070"

OUTPUT_PATH = r"C:\Users\Olatu\Desktop\Thesis_Data\8_NonOrderly_Hotspots_Tricky_HeavyNoise.shp"

np.random.seed(42)

print("Generating 8 non-orderly strong hotspots with plenty of noise...")

# Uniform candidates
x = np.random.uniform(X_MIN, X_MAX, N_POINTS)
y = np.random.uniform(Y_MIN, Y_MAX, N_POINTS)

# 8 hotspot definitions - irregular/non-orderly positions
hotspots = [
    (1.8, 2.3, 0.62, 14.5),   # bottom-left area
    (1.9, 6.8, 0.58, 14.5),   # left side
    (3.4, 8.1, 0.65, 14.5),   # upper leftish
    (5.2, 3.9, 0.70, 14.5),   # center-lower
    (6.8, 7.4, 0.60, 14.5),   # upper center-right
    (8.1, 1.7, 0.55, 14.5),   # bottom-right
    (8.7, 5.6, 0.68, 14.5),   # right-middle
    (4.6, 5.8, 0.72, 14.5)    # near center (slightly offset)
]

# Build hotspot density
density = np.zeros(N_POINTS)

for cx, cy, sigma, amp in hotspots:
    dist_sq = (x - cx)**2 + (y - cy)**2
    gaussian = amp * np.exp(-dist_sq / (2 * sigma**2))
    density += gaussian

# Low base background
density += 0.06

# === PLENTY OF NOISE (makes it very tricky) ===
noise_medium = 2.2 * np.random.normal(0, 1.6, N_POINTS)   # medium fake clusters
noise_fine   = 2.8 * np.random.normal(0, 1.3, N_POINTS)   # dense background scatter
noise_grain  = 2.0 * np.random.normal(0, 1.0, N_POINTS)   # fine grain
noise_spikes = 1.7 * np.abs(np.random.normal(0, 0.9, N_POINTS))  # random spikes

density += noise_medium + noise_fine + noise_grain + noise_spikes

# Ensure non-negative
density = np.maximum(density, 0)

# Strong contrast
density = density ** 2.6

# Normalize
density /= density.sum()

# Sample points
indices = np.random.choice(N_POINTS, N_POINTS, p=density, replace=True)

# Small jitter
x_final = x[indices] + np.random.normal(0, 0.03, N_POINTS)
y_final = y[indices] + np.random.normal(0, 0.03, N_POINTS)

x_final = np.clip(x_final, X_MIN, X_MAX)
y_final = np.clip(y_final, Y_MIN, Y_MAX)

# Create GeoDataFrame
gdf = gpd.GeoDataFrame(
    {'x': x_final, 'y': y_final},
    geometry=[Point(xy) for xy in zip(x_final, y_final)],
    crs=CRS
)

# Save
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
gdf.to_file(OUTPUT_PATH, driver='ESRI Shapefile', encoding='utf-8')

print(f"\nDone! File saved to:")
print(OUTPUT_PATH)
print(f"→ {len(gdf):,} points")
print("\nExpected appearance:")
print("- 8 strong hotspots placed irregularly (non-orderly)")
print("- Roughly equal population in each of the 8 hotspots")
print("- Plenty of heavy noise: random scatter + misleading small clusters everywhere")
print("- Very tricky pattern: noise makes it hard to clearly identify all 8 hotspots")
print("In ArcGIS Pro: small point size (1–1.3 pt), bright color, no fill")
print("Zoom in/out → the map looks chaotic; careful inspection reveals the 8 main clusters")